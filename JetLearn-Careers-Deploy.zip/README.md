
  # JetLearn Careers Page

  This is a code bundle for JetLearn Careers Page. The original project is available at https://www.figma.com/design/5DSqINDYkEQ2AYkDGf7bbv/JetLearn-Careers-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  